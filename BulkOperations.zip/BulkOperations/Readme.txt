Bulk Operations SAMPLE
-------------------------------
NCACHE FEATURES USED
--------------------
This sample deals with the following feature of NCache.
	i)	Bulk operations

INTRODUCTION
------------
This is a sample application based on 'Bulk Operations' feature. 

DESCRIPTION
-----------
This program performs simple AddBulk, GetBulk, InsertBulk & RemoveBulk operations.

HOW TO RUN THE SAMPLE
---------------------

1. Open the solution.
2. The program is currently supposed to connect with a cache named "mypartitionedcache".
3. You can change the name of the cache in the NCache.Initialize() method.
4. Start the project named BulkOperations.

Bulk Operations settings:
-----------------------------

	Make sure the NCache service is running.


