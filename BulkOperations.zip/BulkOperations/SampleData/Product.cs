﻿using System;

// ===============================================================================
// Alachisoft (R) NCache Sample Code
// NCache Product Class used by samples
// ===============================================================================
// Copyright © Alachisoft.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
// ===============================================================================

namespace Alachisoft.NCache.sample.data
{

	[Serializable]
	public class Product
	{
		public int productId;
		public string name;
		public string productClass;
		public string category;

        public Product() { }

        public Product(int pId, string pName, string pClass, string pCategory)
        {
            this.productId = pId;
            this.name = pName;
            this.productClass = pClass;
            this.category = pCategory;
        }

		public virtual int Id
		{
			set
			{
				this.productId = value;
			}
			get
			{
				return this.productId;
			}
		}


		public virtual string Name
		{
			set
			{
				this.name = value;
			}
			get
			{
				return this.name;
			}
		}


		public virtual string ClassName
		{
			set
			{
				this.productClass = value;
			}
			get
			{
				return this.productClass;
			}
		}


		public virtual string Category
		{
			set
			{
				this.category = value;
			}
			get
			{
				return this.category;
			}
		}



	}

}